// MainForm.cs – Phiên bản tiếng Việt
using System;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI_Terminal
{
    public class MainForm : Form
    {
        // ────────── Điều khiển giao diện ──────────
        private ComboBox cbPort, cbBaud, cbDataBits, cbStopBits, cbParity, cbFlow;
        private Button   btnRefresh, btnConnect, btnDisconnect;
        private RichTextBox rtbLog;
        private TextBox  txtSend, txtDigit;
        private Button   btnSend, btnGo, btnPause, btnMove, btnInsert;
        private Label    lblTitle, lblAuthor;

        // ────────── Cổng COM & ghi file ──────────
        private readonly SerialPort serial;
        private readonly StreamWriter? logFile;

        public MainForm()
        {
            // ─────── Cấu hình Form ───────
            Text = "UART Terminal";
            ClientSize = new Size(720, 600);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            // ─────── Tiêu đề dự án ───────
            lblTitle = new Label {
                Text  = "THIẾT KẾ BỘ GIAO TIẾP UART KẾT NỐI MÁY TÍNH VỚI FPGA",
                Font  = new Font("Tahoma", 14, FontStyle.Bold),
                ForeColor = Color.FromArgb(51, 102, 204),
                AutoSize  = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Left = 0, Top = 5, Width = ClientSize.Width, Height = 30
            };
            lblAuthor = new Label {
                Text  = "Bùi Minh Nhựt – 2120707070",
                Font  = new Font("Tahoma", 10, FontStyle.Bold),
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Left = 0, Top = 35, Width = ClientSize.Width, Height = 20
            };

            int ctrlTop = 65; // bắt đầu các control cấu hình

            // ─────── Chọn cổng / baud ───────
            cbPort   = new ComboBox { Left = 10,  Top = ctrlTop, Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
            btnRefresh   = new Button { Left = 140, Top = ctrlTop, Width = 80,  Text = "Làm mới" };
            cbBaud   = new ComboBox { Left = 230, Top = ctrlTop, Width = 100, DropDownStyle = ComboBoxStyle.DropDownList };
            cbBaud.Items.AddRange(new object[]{ "4800","9600","19200","38400","57600","115200" });
            cbBaud.SelectedItem = "9600";
            btnConnect    = new Button { Left = 345, Top = ctrlTop, Width = 80,  Text = "Kết nối" };
            btnDisconnect = new Button { Left = 435, Top = ctrlTop, Width = 100, Text = "Ngắt kết nối", Enabled = false };

            // ─────── Tham số UART ───────
            cbDataBits = new ComboBox { Left = 10,  Top = ctrlTop+40, Width = 60,  DropDownStyle = ComboBoxStyle.DropDownList };
            cbDataBits.Items.AddRange(new object[]{ "5","6","7","8" }); cbDataBits.SelectedItem = "8";
            cbStopBits = new ComboBox { Left = 80,  Top = ctrlTop+40, Width = 60,  DropDownStyle = ComboBoxStyle.DropDownList };
            cbStopBits.Items.AddRange(new object[]{ "1","1.5","2" }); cbStopBits.SelectedItem = "1";
            cbParity   = new ComboBox { Left = 150, Top = ctrlTop+40, Width = 80,  DropDownStyle = ComboBoxStyle.DropDownList };
            cbParity.Items.AddRange(new object[]{ "None","Odd","Even","Mark","Space" }); cbParity.SelectedItem = "None";
            cbFlow    = new ComboBox { Left = 240, Top = ctrlTop+40, Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
            cbFlow.Items.AddRange(new object[]{ "None","XOn/XOff","RTS/CTS","RTS+XOn/XOff" }); cbFlow.SelectedItem = "None";
// Vùng hiển thị log
rtbLog = new RichTextBox {
    Left = 10,
    Top  = ctrlTop + 80,   // 145
    Width  = 700,
    Height = 370,          // ↓ 390 → 370
    ReadOnly = true,
    Font = new Font("Consolas", 10),
    BackColor = Color.White
};

// Gửi lệnh
txtSend = new TextBox { Left = 10, Top = 535, Width = 260 };   // ↑ 525 → 535
btnSend = new Button  { Left = 280, Top = 533, Width = 80, Text = "Gửi" };
// và tương tự cho các nút khác
btnGo    = new Button { Left = 370, Top = 535, Width = 60, Text = "Go" };
btnPause = new Button { Left = 440, Top = 535, Width = 60, Text = "Pause" };
btnMove  = new Button { Left = 510, Top = 535, Width = 60, Text = "Move" };
txtDigit = new TextBox{ Left = 580, Top = 535, Width = 40, MaxLength = 1 };
btnInsert= new Button { Left = 630, Top = 533, Width = 80, Text = "Chèn" };


            Controls.AddRange(new Control[]{
                lblTitle, lblAuthor,
                cbPort, btnRefresh, cbBaud, btnConnect, btnDisconnect,
                cbDataBits, cbStopBits, cbParity, cbFlow,
                rtbLog,
                txtSend, btnSend, btnGo, btnPause, btnMove, txtDigit, btnInsert
            });

            // ─────── Cấu hình SerialPort ───────
            serial = new SerialPort {
                BaudRate = 9600, DataBits = 8,
                Parity = Parity.None, StopBits = StopBits.One, Handshake = Handshake.None
            };
            serial.DataReceived += Serial_DataReceived;

            // ─────── Tạo file log ───────
            try {
                string dir = @"C:\Users\buimi\Desktop\SerialTerminalApp\UI_Terminal\logs";
                Directory.CreateDirectory(dir);
                string fname = Path.Combine(dir, $"uart_{DateTime.Now:yyyyMMdd_HHmmss}.log");
                logFile = new StreamWriter(fname, false, Encoding.UTF8) { AutoFlush = true };
            } catch { logFile = null; }

            // ─────── Gắn sự kiện ───────
            btnRefresh.Click += (_,__) => RefreshPorts();
            btnConnect.Click += async (_,__) => await ConnectAsync();
            btnDisconnect.Click += (_,__) => NgatKetNoi();
            btnSend.Click += (_,__) => GuiKyTu(txtSend.Text);
            txtSend.KeyDown += (_,e)=>{ if(e.KeyCode==Keys.Enter){ GuiKyTu(txtSend.Text); e.SuppressKeyPress=true;} };
            btnGo.Click    += (_,__) => GuiKyTu("g");
            btnPause.Click += (_,__) => GuiKyTu("p");
            btnMove.Click  += (_,__) => GuiKyTu("m");
            btnInsert.Click+= (_,__) => { if(txtDigit.Text.Length==1 && char.IsDigit(txtDigit.Text[0])) GuiKyTu(txtDigit.Text); };

            Load += (_,__) => RefreshPorts();
            FormClosing += (_,__) => { if(serial.IsOpen) serial.Close(); logFile?.Dispose(); };
        }

        // ─────── Làm mới danh sách cổng ───────
        private void RefreshPorts()
        {
            cbPort.Items.Clear();
            cbPort.Items.AddRange(SerialPort.GetPortNames());
            if (cbPort.Items.Count>0) cbPort.SelectedIndex = 0;
        }

        // ─────── Kết nối ───────
        private async Task ConnectAsync()
        {
            btnConnect.Enabled = false;
            btnRefresh.Enabled = false;
            GhiThongBao("Đang mở cổng...");
            try {
                serial.PortName = cbPort.Text;
                serial.BaudRate = int.Parse(cbBaud.Text);
                serial.DataBits = int.Parse(cbDataBits.Text);
                serial.Parity = cbParity.Text switch {
                    "Odd"=>Parity.Odd,"Even"=>Parity.Even,"Mark"=>Parity.Mark,"Space"=>Parity.Space,_=>Parity.None };
                serial.StopBits = cbStopBits.Text switch { "1.5"=>StopBits.OnePointFive,"2"=>StopBits.Two,_=>StopBits.One };
                serial.Handshake = cbFlow.Text switch {
                    "XOn/XOff"=>Handshake.XOnXOff,"RTS/CTS"=>Handshake.RequestToSend,
                    "RTS+XOn/XOff"=>Handshake.RequestToSendXOnXOff,_=>Handshake.None };

                await Task.Run(()=>serial.Open());
                serial.DiscardInBuffer(); serial.DiscardOutBuffer();
                serial.DtrEnable = true; serial.RtsEnable = true;

                btnDisconnect.Enabled = true;
                GhiThongBao($"Đã kết nối {serial.PortName}@{serial.BaudRate}");
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message,"Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
                btnConnect.Enabled = true;
            }
            finally { btnRefresh.Enabled = true; }
        }

        // ─────── Ngắt kết nối ───────
        private void NgatKetNoi()
        {
            if (serial.IsOpen) serial.Close();
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
            GhiThongBao("Đã ngắt kết nối.");
        }

        // ─────── Gửi 1 ký tự ───────
        private void GuiKyTu(string cmd)
        {
            if (string.IsNullOrEmpty(cmd) || !serial.IsOpen) return;
            byte b = (byte)cmd[0];
            serial.Write(new byte[]{b},0,1);
            GhiThongBao($"[TX] '{(char)b}'");
            txtSend.Clear();
        }

        // ─────── Nhận dữ liệu ───────
        private void Serial_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int n = serial.BytesToRead; if(n==0) return;
            var buf = new byte[n]; serial.Read(buf,0,n);

            foreach(byte b in buf)
            {
                string printable = b switch { 0x0D=>"\\r",0x0A=>"\\n",_=>((char)b).ToString() };
                logFile?.WriteLine($"[RX] '{printable}'");
            }
        }

        // ─────── Ghi ra UI + file ───────
        private void GhiThongBao(string text)
        {
            rtbLog.Invoke((Action)(()=>
            {
                rtbLog.AppendText($"[TB] {text}\r\n");
                rtbLog.ScrollToCaret();
            }));
            logFile?.WriteLine($"[TB] {text}");
        }
    }
}
